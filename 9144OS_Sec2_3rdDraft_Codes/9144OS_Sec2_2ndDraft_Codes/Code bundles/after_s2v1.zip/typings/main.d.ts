/// <reference path="main/ambient/es6-shim/es6-shim.d.ts" />
