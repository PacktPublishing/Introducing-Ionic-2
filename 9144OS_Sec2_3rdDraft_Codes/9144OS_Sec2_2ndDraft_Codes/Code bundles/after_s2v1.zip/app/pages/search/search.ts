import {Page, NavController} from 'ionic-framework/ionic';
@Page({
  templateUrl: 'build/pages/search/search.html',
})
export class SearchPage {
  constructor(private nav: NavController) {
  }
}
