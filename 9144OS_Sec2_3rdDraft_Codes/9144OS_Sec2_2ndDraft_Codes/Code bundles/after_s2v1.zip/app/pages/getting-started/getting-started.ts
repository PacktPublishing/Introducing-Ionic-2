import {Page} from 'ionic-framework/ionic';


@Page({
  templateUrl: 'build/pages/getting-started/getting-started.html'
})
export class GettingStartedPage {
  
}
