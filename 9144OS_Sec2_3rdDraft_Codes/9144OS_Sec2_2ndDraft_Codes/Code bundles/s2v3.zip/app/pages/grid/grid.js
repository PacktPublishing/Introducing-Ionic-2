import {Page} from 'ionic/ionic';


@Page({
  templateUrl: 'build/pages/grid/grid.html'
})
export class GridPage {}
