import {Page, NavController} from 'ionic/ionic';


@Page({
  templateUrl: 'build/pages/getting-started/getting-started.html'
})
export class GettingStartedPage {
  constructor(nav: NavController) {

  }

}
